# Vercel fix

Changes in this package:

- Removed the forced "Identitas sesi" modal from the landing page.
- Identity can be synchronized silently from an existing full-name field or through `window.KBRealtime.setIdentity(fullName)`.
- No random/fake user name is generated; unnamed sessions remain `Belum diidentifikasi`.
- SQLite path uses `/tmp/kb-realtime.sqlite` on Vercel to avoid `/var/task/data` write failures.
- Admin chat fallback label changed from `Unknown` to `Belum diidentifikasi`.

Important: `/tmp` is ephemeral on Vercel. This fixes runtime startup but is not durable production storage. For persistent multi-instance realtime state, migrate SQLite/in-memory event state to external PostgreSQL/Redis/pub-sub.
