'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT || 3000);
const DB_PATH = process.env.KB_DB_PATH || (
  process.env.VERCEL
    ? '/tmp/kb-realtime.sqlite'
    : path.join(ROOT, 'data', 'kb-realtime.sqlite')
);
const ADMIN_EMAIL = String(process.env.KB_ADMIN_EMAIL || 'admin@example.local').toLowerCase();
const ADMIN_PASSWORD = process.env.KB_ADMIN_PASSWORD || '';
const TEST_MODE = process.env.KB_TEST_MODE === '1';

if (ADMIN_PASSWORD.length < 12) {
  console.error('KB_ADMIN_PASSWORD wajib diisi dan minimal 12 karakter.');
  process.exit(1);
}

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  full_name TEXT,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','RESTRICTED','BLOCKED')),
  access_state TEXT NOT NULL DEFAULT 'ALLOWED' CHECK(access_state IN ('ALLOWED','DENIED')),
  blocked_reason TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  online_until TEXT,
  last_activity TEXT,
  current_page TEXT NOT NULL DEFAULT '/#top',
  progress INTEGER NOT NULL DEFAULT 0,
  chat_status TEXT NOT NULL DEFAULT 'OFFLINE'
);
CREATE TABLE IF NOT EXISTS user_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf_token TEXT NOT NULL,
  created_at TEXT NOT NULL,
  last_activity TEXT NOT NULL,
  current_page TEXT NOT NULL DEFAULT '/#top',
  revoked_at TEXT,
  revoke_reason TEXT
);
CREATE TABLE IF NOT EXISTS admins (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('SUPER_ADMIN','OPERATOR','CUSTOMER_SUPPORT')),
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS admin_sessions (
  id TEXT PRIMARY KEY,
  admin_id TEXT NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  csrf_token TEXT NOT NULL,
  created_at TEXT NOT NULL,
  last_activity TEXT NOT NULL,
  revoked_at TEXT
);
CREATE TABLE IF NOT EXISTS chat_messages (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sender_type TEXT NOT NULL CHECK(sender_type IN ('USER','ADMIN')),
  sender_id TEXT NOT NULL,
  body TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('SENT','DELIVERED','READ')),
  created_at TEXT NOT NULL,
  delivered_at TEXT,
  read_at TEXT
);
CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  admin_id TEXT NOT NULL REFERENCES admins(id),
  target_user_id TEXT,
  action TEXT NOT NULL,
  created_at TEXT NOT NULL,
  previous_state TEXT,
  new_state TEXT,
  reason TEXT,
  metadata TEXT
);
CREATE TABLE IF NOT EXISTS activity_log (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_id TEXT,
  type TEXT NOT NULL,
  detail TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS navigation_commands (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  admin_id TEXT NOT NULL REFERENCES admins(id),
  route_id TEXT NOT NULL,
  route_path TEXT NOT NULL,
  created_at TEXT NOT NULL
);
`);

const ROUTES = Object.freeze({
  home: { id: 'home', label: 'Beranda', path: '/#top', progress: 10 },
  process: { id: 'process', label: 'Proses Pengajuan', path: '/#proses', progress: 35 },
  products: { id: 'products', label: 'Jenis Pinjaman', path: '/#jenis-pinjaman', progress: 65 },
  footer: { id: 'footer', label: 'Informasi & Footer', path: '/#footer-kb-bank', progress: 90 }
});
const PATH_TO_ROUTE = new Map(Object.values(ROUTES).map(r => [r.path, r]));

const PERMISSIONS = Object.freeze({
  SUPER_ADMIN: new Set(['monitor','chat','navigate','allow','deny','restrict','block','unblock','terminate','audit','manage_admins']),
  OPERATOR: new Set(['monitor','chat','navigate']),
  CUSTOMER_SUPPORT: new Set(['chat'])
});

const now = () => new Date().toISOString();
const id = (prefix='id') => `${prefix}_${crypto.randomUUID()}`;
const safeJson = obj => JSON.stringify(obj ?? null);
const parseJsonSafe = v => { try { return JSON.parse(v); } catch { return v; } };

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, expected] = String(stored).split(':');
  if (!salt || !expected) return false;
  const actual = crypto.scryptSync(password, salt, 64);
  const exp = Buffer.from(expected, 'hex');
  return actual.length === exp.length && crypto.timingSafeEqual(actual, exp);
}

const existingAdmin = db.prepare('SELECT id FROM admins WHERE email=?').get(ADMIN_EMAIL);
if (!existingAdmin) {
  db.prepare('INSERT INTO admins(id,email,full_name,role,password_hash,created_at,active) VALUES(?,?,?,?,?,?,1)')
    .run(id('adm'), ADMIN_EMAIL, 'Super Admin', 'SUPER_ADMIN', hashPassword(ADMIN_PASSWORD), now());
}

function cookies(req) {
  const out = {};
  const raw = req.headers.cookie || '';
  for (const part of raw.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    out[part.slice(0,i).trim()] = decodeURIComponent(part.slice(i+1).trim());
  }
  return out;
}
function setCookie(res, name, value, opts={}) {
  const bits = [`${name}=${encodeURIComponent(value)}`, 'Path=/', 'HttpOnly', 'SameSite=Strict'];
  if (opts.maxAge) bits.push(`Max-Age=${opts.maxAge}`);
  if (process.env.NODE_ENV === 'production') bits.push('Secure');
  const prev = res.getHeader('Set-Cookie');
  res.setHeader('Set-Cookie', prev ? [...(Array.isArray(prev)?prev:[prev]), bits.join('; ')] : bits.join('; '));
}
function json(res, status, data, extra={}) {
  res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store', ...extra });
  res.end(JSON.stringify(data));
}
function text(res, status, body, type='text/plain; charset=utf-8') {
  res.writeHead(status, { 'Content-Type':type, 'Cache-Control':'no-store' });
  res.end(body);
}
function readBody(req, max=64_000) {
  return new Promise((resolve,reject) => {
    let data='';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > max) { reject(new Error('BODY_TOO_LARGE')); req.destroy(); }
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); } catch { reject(new Error('INVALID_JSON')); }
    });
    req.on('error', reject);
  });
}
function normalizeName(v) {
  return String(v||'').trim().replace(/\s+/g,' ').slice(0,100);
}
function redactSensitive(v) {
  let s = String(v||'').trim().slice(0,2000);
  const labels = '(password|passcode|pin|otp|cvv|token|secret|kode\\s*keamanan)';
  s = s.replace(new RegExp(`(${labels}\\s*[:=]?\\s*)([^\\s,;]{2,})`, 'gi'), '$1[REDACTED]');
  return s;
}
function routeFromInput(page) {
  const value = String(page || '/#top');
  if (PATH_TO_ROUTE.has(value)) return PATH_TO_ROUTE.get(value);
  if (value === '/' || value === '/index.html') return ROUTES.home;
  const hash = value.includes('#') ? '/#'+value.split('#')[1] : '/#top';
  return PATH_TO_ROUTE.get(hash) || ROUTES.home;
}
function logActivity(userId, sessionId, type, detail='') {
  db.prepare('INSERT INTO activity_log(id,user_id,session_id,type,detail,created_at) VALUES(?,?,?,?,?,?)')
    .run(id('act'), userId, sessionId || null, type, String(detail).slice(0,1000), now());
}
function audit(admin, targetUserId, action, previousState, newState, reason='', metadata={}) {
  db.prepare('INSERT INTO audit_log(id,admin_id,target_user_id,action,created_at,previous_state,new_state,reason,metadata) VALUES(?,?,?,?,?,?,?,?,?)')
    .run(id('aud'), admin.id, targetUserId || null, action, now(), safeJson(previousState), safeJson(newState), String(reason||'').slice(0,500), safeJson(metadata));
}

function userState(userId) {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(userId);
  return u ? { status:u.status, access_state:u.access_state, blocked_reason:u.blocked_reason } : null;
}
function adminHas(admin, permission) {
  return !!admin && PERMISSIONS[admin.role]?.has(permission);
}

const adminStreams = new Map();
const userStreams = new Map();
function addStream(map, key, res) {
  if (!map.has(key)) map.set(key, new Set());
  map.get(key).add(res);
  res.on('close', () => {
    map.get(key)?.delete(res);
    if (map.get(key)?.size === 0) map.delete(key);
  });
}
function sseWrite(res, event, data) {
  try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); return true; } catch { return false; }
}
function broadcastAdmins(event, data) {
  for (const set of adminStreams.values()) for (const res of set) sseWrite(res,event,data);
}
function broadcastUser(userId,event,data) {
  for (const res of userStreams.get(userId) || []) sseWrite(res,event,data);
}
setInterval(() => {
  for (const set of adminStreams.values()) for (const res of set) res.write(': ping\n\n');
  for (const set of userStreams.values()) for (const res of set) res.write(': ping\n\n');
}, 15000).unref();

function ensureUser(req,res,{create=true}={}) {
  const c = cookies(req);
  let userId = c.kb_uid;
  let sessionId = c.kb_sid;
  let user = userId ? db.prepare('SELECT * FROM users WHERE id=?').get(userId) : null;
  const t = now();
  if (!user && create) {
    userId = id('usr');
    db.prepare('INSERT INTO users(id,created_at,updated_at,last_activity,online_until,current_page,progress,chat_status) VALUES(?,?,?,?,?,?,?,?)')
      .run(userId,t,t,t,new Date(Date.now()+30000).toISOString(),'/#top',10,'ONLINE');
    user = db.prepare('SELECT * FROM users WHERE id=?').get(userId);
    setCookie(res,'kb_uid',userId,{maxAge:60*60*24*30});
    logActivity(userId,null,'USER_CREATED','Website session identity created');
    broadcastAdmins('user.created',{user_id:userId});
  }
  if (!user) return { error:'NO_USER' };
  if (user.status === 'BLOCKED') return { error:'BLOCKED', user };
  if (user.access_state === 'DENIED') return { error:'ACCESS_DENIED', user };

  let session = sessionId ? db.prepare('SELECT * FROM user_sessions WHERE id=? AND user_id=?').get(sessionId,user.id) : null;
  if (session?.revoked_at) return { error:'SESSION_TERMINATED', user, session };
  if (!session && create) {
    sessionId = id('ses');
    const csrf = crypto.randomBytes(24).toString('base64url');
    db.prepare('INSERT INTO user_sessions(id,user_id,csrf_token,created_at,last_activity,current_page) VALUES(?,?,?,?,?,?)')
      .run(sessionId,user.id,csrf,t,t,user.current_page || '/#top');
    session = db.prepare('SELECT * FROM user_sessions WHERE id=?').get(sessionId);
    setCookie(res,'kb_sid',sessionId);
    logActivity(user.id,sessionId,'SESSION_STARTED','User session started');
    broadcastAdmins('session.started',{user_id:user.id,session_id:sessionId});
  }
  return { user, session };
}
function ensureAdmin(req,res) {
  const c = cookies(req);
  const sid = c.kb_admin_sid;
  if (!sid) return { error:'UNAUTHENTICATED' };
  const row = db.prepare(`SELECT s.*,a.email,a.full_name,a.role,a.active FROM admin_sessions s JOIN admins a ON a.id=s.admin_id WHERE s.id=?`).get(sid);
  if (!row || row.revoked_at || !row.active) return { error:'UNAUTHENTICATED' };
  db.prepare('UPDATE admin_sessions SET last_activity=? WHERE id=?').run(now(),sid);
  return { admin:{id:row.admin_id,email:row.email,full_name:row.full_name,role:row.role}, session:row };
}
function verifyCsrf(req, session) {
  const a=Buffer.from(String(req.headers['x-csrf-token']||'')), b=Buffer.from(String(session.csrf_token||''));
  return a.length===b.length && a.length>0 && crypto.timingSafeEqual(a,b);
}
function enforceUser(req,res) {
  const ctx = ensureUser(req,res,{create:true});
  if (ctx.error === 'BLOCKED') { json(res,403,{error:'BLOCKED',message:'Akses diblokir oleh server.'}); return null; }
  if (ctx.error === 'ACCESS_DENIED') { json(res,403,{error:'ACCESS_DENIED',message:'Akses ditolak oleh server.'}); return null; }
  if (ctx.error === 'SESSION_TERMINATED') { json(res,401,{error:'SESSION_TERMINATED',message:'Session telah diakhiri oleh admin.'}); return null; }
  return ctx;
}
function enforceAdmin(req,res,permission=null) {
  const ctx = ensureAdmin(req,res);
  if (ctx.error) { json(res,401,{error:'UNAUTHENTICATED'}); return null; }
  if (permission && !adminHas(ctx.admin,permission)) { json(res,403,{error:'FORBIDDEN'}); return null; }
  return ctx;
}

function currentUsers() {
  const rows = db.prepare(`
    SELECT u.*,
      (SELECT id FROM user_sessions s WHERE s.user_id=u.id AND s.revoked_at IS NULL ORDER BY s.created_at DESC LIMIT 1) session_id,
      (SELECT COUNT(*) FROM chat_messages m WHERE m.user_id=u.id AND m.sender_type='USER' AND m.status!='READ') unread_messages
    FROM users u ORDER BY u.created_at DESC
  `).all();
  const nowMs = Date.now();
  return rows.map(r => {
    const online=!!r.online_until && new Date(r.online_until).getTime() > nowMs;
    return {
      id:r.id, full_name:r.full_name || 'Belum diidentifikasi', status:r.status, access_state:r.access_state,
      online, current_page:r.current_page, last_activity:r.last_activity, progress:r.progress,
      chat_status:online?'ONLINE':'OFFLINE', session_id:r.session_id, unread_messages:Number(r.unread_messages||0), created_at:r.created_at,
      blocked_reason:r.blocked_reason || null
    };
  });
}
function dashboardStats() {
  const users = currentUsers();
  const today = new Date(); today.setHours(0,0,0,0);
  return {
    online_users: users.filter(u=>u.online).length,
    active_sessions: users.filter(u=>u.session_id).length,
    active_chats: users.filter(u=>u.chat_status==='ONLINE').length,
    unread_messages: users.reduce((n,u)=>n+u.unread_messages,0),
    new_users: users.filter(u=>new Date(u.created_at)>=today).length,
    blocked_users: users.filter(u=>u.status==='BLOCKED').length
  };
}

function serveStatic(req,res,urlPath) {
  let filePath;
  if (urlPath === '/' || urlPath === '/index.html') filePath = path.join(PUBLIC,'index.html');
  else if (urlPath === '/admin' || urlPath === '/admin/') filePath = path.join(PUBLIC,'admin.html');
  else filePath = path.join(PUBLIC, decodeURIComponent(urlPath).replace(/^\/+/,''));
  if (!filePath.startsWith(PUBLIC)) return text(res,403,'Forbidden');
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) return false;
  const ext=path.extname(filePath).toLowerCase();
  const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'};
  res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':ext==='.html'?'no-store':'public, max-age=300','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'});
  fs.createReadStream(filePath).pipe(res);
  return true;
}

async function handler(req,res) {
  const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = u.pathname;
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');

  try {
    // User page itself is server-access-controlled when a known identity is blocked/denied/terminated.
    if ((pathname==='/' || pathname==='/index.html') && req.method==='GET') {
      const c=cookies(req);
      if (c.kb_uid) {
        const user=db.prepare('SELECT * FROM users WHERE id=?').get(c.kb_uid);
        if (user?.status==='BLOCKED') return text(res,403,'Akses diblokir oleh server.');
        if (user?.access_state==='DENIED') return text(res,403,'Akses ditolak oleh server.');
      }
      if (c.kb_sid) {
        const s=db.prepare('SELECT revoked_at FROM user_sessions WHERE id=?').get(c.kb_sid);
        if (s?.revoked_at) return text(res,401,'Session telah diakhiri oleh admin.');
      }
      return serveStatic(req,res,pathname);
    }

    if (pathname==='/api/user/bootstrap' && req.method==='GET') {
      const ctx=enforceUser(req,res); if(!ctx) return;
      db.prepare('UPDATE users SET online_until=?,last_activity=?,chat_status=?,updated_at=? WHERE id=?')
        .run(new Date(Date.now()+30000).toISOString(),now(),'ONLINE',now(),ctx.user.id);
      const unread=db.prepare("SELECT COUNT(*) n FROM chat_messages WHERE user_id=? AND sender_type='ADMIN' AND status!='READ'").get(ctx.user.id).n; return json(res,200,{user:{id:ctx.user.id,full_name:ctx.user.full_name,status:ctx.user.status,access_state:ctx.user.access_state,current_page:ctx.user.current_page},session:{id:ctx.session.id,csrf_token:ctx.session.csrf_token},routes:Object.values(ROUTES),unread_messages:Number(unread||0)});
    }

    if (pathname==='/api/user/identity' && req.method==='POST') {
      const ctx=enforceUser(req,res); if(!ctx) return;
      if(!verifyCsrf(req,ctx.session)) return json(res,403,{error:'CSRF'});
      const body=await readBody(req); const fullName=normalizeName(body.full_name);
      if(fullName.length<3) return json(res,422,{error:'INVALID_NAME'});
      const previous=ctx.user.full_name;
      db.prepare('UPDATE users SET full_name=?,updated_at=?,last_activity=? WHERE id=?').run(fullName,now(),now(),ctx.user.id);
      logActivity(ctx.user.id,ctx.session.id,'IDENTITY_UPDATED', previous ? 'Full name updated' : 'Full name set');
      broadcastAdmins('user.updated',{user_id:ctx.user.id});
      return json(res,200,{id:ctx.user.id,full_name:fullName});
    }

    if (pathname==='/api/user/presence' && req.method==='POST') {
      const ctx=enforceUser(req,res); if(!ctx) return;
      if(!verifyCsrf(req,ctx.session)) return json(res,403,{error:'CSRF'});
      const body=await readBody(req); const route=routeFromInput(body.page);
      const t=now(), until=new Date(Date.now()+30000).toISOString();
      db.prepare('UPDATE users SET current_page=?,progress=?,online_until=?,last_activity=?,chat_status=?,updated_at=? WHERE id=?')
        .run(route.path,route.progress,until,t,'ONLINE',t,ctx.user.id);
      db.prepare('UPDATE user_sessions SET current_page=?,last_activity=? WHERE id=?').run(route.path,t,ctx.session.id);
      logActivity(ctx.user.id,ctx.session.id,'PAGE_VIEW',route.path);
      broadcastAdmins('presence.updated',{user_id:ctx.user.id,current_page:route.path,progress:route.progress});
      return json(res,200,{ok:true,current_page:route.path,progress:route.progress});
    }

    if (pathname==='/api/chat/messages' && req.method==='GET') {
      const ctx=enforceUser(req,res); if(!ctx) return;
      db.prepare("UPDATE chat_messages SET status='READ',read_at=? WHERE user_id=? AND sender_type='ADMIN' AND status!='READ'").run(now(),ctx.user.id);
      const rows=db.prepare(`SELECT m.*, CASE WHEN m.sender_type='USER' THEN u.full_name ELSE a.full_name END sender_name
        FROM chat_messages m JOIN users u ON u.id=m.user_id LEFT JOIN admins a ON a.id=m.sender_id AND m.sender_type='ADMIN'
        WHERE m.user_id=? ORDER BY m.created_at ASC LIMIT 500`).all(ctx.user.id);
      broadcastAdmins('chat.read',{user_id:ctx.user.id,reader:'USER'});
      return json(res,200,{messages:rows.map(r=>({...r,sender_name:r.sender_name||'Customer Care'}))});
    }

    if (pathname==='/api/chat/messages' && req.method==='POST') {
      const ctx=enforceUser(req,res); if(!ctx) return;
      if(!verifyCsrf(req,ctx.session)) return json(res,403,{error:'CSRF'});
      const body=await readBody(req); const msg=redactSensitive(body.message);
      if(!msg) return json(res,422,{error:'EMPTY_MESSAGE'});
      const mid=id('msg'), t=now(); const delivered=adminStreams.size>0;
      db.prepare('INSERT INTO chat_messages(id,user_id,sender_type,sender_id,body,status,created_at,delivered_at) VALUES(?,?,?,?,?,?,?,?)')
        .run(mid,ctx.user.id,'USER',ctx.user.id,msg,delivered?'DELIVERED':'SENT',t,delivered?t:null);
      db.prepare("UPDATE users SET chat_status='ONLINE',last_activity=?,updated_at=? WHERE id=?").run(t,t,ctx.user.id);
      logActivity(ctx.user.id,ctx.session.id,'CHAT_MESSAGE','User sent a chat message');
      const payload={id:mid,user_id:ctx.user.id,sender_type:'USER',sender_name:ctx.user.full_name||'Belum diidentifikasi',body:msg,status:delivered?'DELIVERED':'SENT',created_at:t};
      broadcastAdmins('chat.message',payload);
      return json(res,201,payload);
    }

    if (pathname==='/api/chat/typing' && req.method==='POST') {
      const ctx=enforceUser(req,res); if(!ctx) return;
      if(!verifyCsrf(req,ctx.session)) return json(res,403,{error:'CSRF'});
      const body=await readBody(req);
      broadcastAdmins('chat.typing',{user_id:ctx.user.id,typing:!!body.typing});
      return json(res,200,{ok:true});
    }

    if (pathname==='/events/user' && req.method==='GET') {
      const ctx=enforceUser(req,res); if(!ctx) return;
      res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});
      res.write('retry: 2000\n\n'); addStream(userStreams,ctx.user.id,res);
      db.prepare("UPDATE users SET online_until=?,chat_status='ONLINE',last_activity=?,updated_at=? WHERE id=?")
        .run(new Date(Date.now()+30000).toISOString(),now(),now(),ctx.user.id);
      broadcastAdmins('presence.updated',{user_id:ctx.user.id,online:true});
      sseWrite(res,'ready',{user_id:ctx.user.id});
      return;
    }

    if (pathname==='/api/admin/login' && req.method==='POST') {
      const body=await readBody(req); const email=String(body.email||'').toLowerCase().trim();
      const a=db.prepare('SELECT * FROM admins WHERE email=? AND active=1').get(email);
      if(!a || !verifyPassword(String(body.password||''),a.password_hash)) return json(res,401,{error:'INVALID_CREDENTIALS'});
      const sid=id('as'), csrf=crypto.randomBytes(24).toString('base64url'), t=now();
      db.prepare('INSERT INTO admin_sessions(id,admin_id,csrf_token,created_at,last_activity) VALUES(?,?,?,?,?)').run(sid,a.id,csrf,t,t);
      setCookie(res,'kb_admin_sid',sid);
      return json(res,200,{admin:{id:a.id,email:a.email,full_name:a.full_name,role:a.role},csrf_token:csrf});
    }

    if (pathname==='/api/admin/me' && req.method==='GET') {
      const ctx=enforceAdmin(req,res); if(!ctx) return;
      return json(res,200,{admin:ctx.admin,csrf_token:ctx.session.csrf_token,permissions:[...PERMISSIONS[ctx.admin.role]]});
    }

    if (pathname==='/api/admin/dashboard' && req.method==='GET') {
      const ctx=enforceAdmin(req,res,'monitor'); if(!ctx) return;
      return json(res,200,{stats:dashboardStats()});
    }

    if (pathname==='/api/admin/users' && req.method==='GET') {
      const ctx=enforceAdmin(req,res,'monitor'); if(!ctx) return;
      return json(res,200,{users:currentUsers()});
    }

    if (pathname==='/api/admin/routes' && req.method==='GET') {
      const ctx=enforceAdmin(req,res,'navigate'); if(!ctx) return;
      return json(res,200,{routes:Object.values(ROUTES)});
    }

    if (pathname==='/api/admin/chat/users' && req.method==='GET') {
      const ctx=enforceAdmin(req,res,'chat'); if(!ctx) return;
      const nowMs=Date.now();
      const rows=db.prepare(`SELECT u.id,u.full_name,u.online_until,
        (SELECT COUNT(*) FROM chat_messages m WHERE m.user_id=u.id AND m.sender_type='USER' AND m.status!='READ') unread_messages
        FROM users u WHERE EXISTS(SELECT 1 FROM chat_messages m2 WHERE m2.user_id=u.id) ORDER BY u.last_activity DESC`).all();
      return json(res,200,{users:rows.map(r=>{const online=!!r.online_until&&new Date(r.online_until).getTime()>nowMs;return {id:r.id,full_name:r.full_name||'Belum diidentifikasi',online,chat_status:online?'ONLINE':'OFFLINE',unread_messages:Number(r.unread_messages||0)}})});
    }

    const navMatch=pathname.match(/^\/api\/admin\/users\/([^/]+)\/navigate$/);
    if (navMatch && req.method==='POST') {
      const ctx=enforceAdmin(req,res,'navigate'); if(!ctx) return;
      if(!verifyCsrf(req,ctx.session)) return json(res,403,{error:'CSRF'});
      const targetId=decodeURIComponent(navMatch[1]); const target=db.prepare('SELECT * FROM users WHERE id=?').get(targetId);
      if(!target) return json(res,404,{error:'USER_NOT_FOUND'});
      const body=await readBody(req); const route=ROUTES[String(body.route_id||'')];
      if(!route) return json(res,422,{error:'ROUTE_NOT_ALLOWED'});
      const command={id:id('nav'),user_id:targetId,admin_id:ctx.admin.id,route_id:route.id,route_path:route.path,created_at:now()};
      db.prepare('INSERT INTO navigation_commands(id,user_id,admin_id,route_id,route_path,created_at) VALUES(?,?,?,?,?,?)')
        .run(command.id,targetId,ctx.admin.id,route.id,route.path,command.created_at);
      audit(ctx.admin,targetId,'ASSIST_NAVIGATION',{current_page:target.current_page},{target_route:route.path},body.reason||'',{route_id:route.id});
      broadcastUser(targetId,'navigate',{route_id:route.id,path:route.path,label:route.label,command_id:command.id});
      broadcastAdmins('audit.created',{action:'ASSIST_NAVIGATION',target_user_id:targetId});
      return json(res,200,{ok:true,route});
    }

    const actionMatch=pathname.match(/^\/api\/admin\/users\/([^/]+)\/(allow|deny|restrict|block|unblock|terminate)$/);
    if (actionMatch && req.method==='POST') {
      const targetId=decodeURIComponent(actionMatch[1]), action=actionMatch[2];
      const permission=action==='terminate'?'terminate':action;
      const ctx=enforceAdmin(req,res,permission); if(!ctx) return;
      if(!verifyCsrf(req,ctx.session)) return json(res,403,{error:'CSRF'});
      const target=db.prepare('SELECT * FROM users WHERE id=?').get(targetId);
      if(!target) return json(res,404,{error:'USER_NOT_FOUND'});
      const body=await readBody(req); const reason=String(body.reason||'').trim();
      if(action==='block' && reason.length<3) return json(res,422,{error:'REASON_REQUIRED'});
      const prev=userState(targetId), t=now();
      if(action==='allow') db.prepare("UPDATE users SET status='ACTIVE',access_state='ALLOWED',blocked_reason=NULL,updated_at=? WHERE id=?").run(t,targetId);
      if(action==='deny') db.prepare("UPDATE users SET status='RESTRICTED',access_state='DENIED',updated_at=? WHERE id=?").run(t,targetId);
      if(action==='restrict') db.prepare("UPDATE users SET status='RESTRICTED',access_state='ALLOWED',updated_at=? WHERE id=?").run(t,targetId);
      if(action==='block') db.prepare("UPDATE users SET status='BLOCKED',access_state='DENIED',blocked_reason=?,updated_at=? WHERE id=?").run(reason,t,targetId);
      if(action==='unblock') db.prepare("UPDATE users SET status='ACTIVE',access_state='ALLOWED',blocked_reason=NULL,updated_at=? WHERE id=?").run(t,targetId);
      if(action==='terminate') db.prepare("UPDATE user_sessions SET revoked_at=?,revoke_reason=? WHERE user_id=? AND revoked_at IS NULL").run(t,reason||'Terminated by admin',targetId);
      const next=userState(targetId);
      audit(ctx.admin,targetId,action.toUpperCase(),prev,next,reason);
      logActivity(targetId,null,'ADMIN_ACTION',action.toUpperCase());
      if(action==='block' || action==='deny') broadcastUser(targetId,'access.revoked',{action,status:next});
      else if(action==='unblock' || action==='allow') broadcastUser(targetId,'access.restored',{action,status:next});
      else if(action==='terminate') broadcastUser(targetId,'session.terminated',{reason:reason||'Session diakhiri admin'});
      broadcastAdmins('user.updated',{user_id:targetId});
      return json(res,200,{ok:true,state:next});
    }

    const adminChatMatch=pathname.match(/^\/api\/admin\/users\/([^/]+)\/messages$/);
    if(adminChatMatch && req.method==='GET') {
      const ctx=enforceAdmin(req,res,'chat'); if(!ctx) return;
      const targetId=decodeURIComponent(adminChatMatch[1]);
      const target=db.prepare('SELECT id,full_name FROM users WHERE id=?').get(targetId);
      if(!target) return json(res,404,{error:'USER_NOT_FOUND'});
      db.prepare("UPDATE chat_messages SET status='READ',read_at=? WHERE user_id=? AND sender_type='USER' AND status!='READ'").run(now(),targetId);
      const rows=db.prepare(`SELECT m.*, CASE WHEN m.sender_type='USER' THEN u.full_name ELSE a.full_name END sender_name
        FROM chat_messages m JOIN users u ON u.id=m.user_id LEFT JOIN admins a ON a.id=m.sender_id AND m.sender_type='ADMIN'
        WHERE m.user_id=? ORDER BY m.created_at ASC LIMIT 500`).all(targetId);
      broadcastUser(targetId,'chat.read',{reader:'ADMIN'});
      return json(res,200,{user:target,messages:rows.map(r=>({...r,sender_name:r.sender_name||'Belum diidentifikasi'}))});
    }
    if(adminChatMatch && req.method==='POST') {
      const ctx=enforceAdmin(req,res,'chat'); if(!ctx) return;
      if(!verifyCsrf(req,ctx.session)) return json(res,403,{error:'CSRF'});
      const targetId=decodeURIComponent(adminChatMatch[1]); const target=db.prepare('SELECT id,full_name FROM users WHERE id=?').get(targetId);
      if(!target) return json(res,404,{error:'USER_NOT_FOUND'});
      const body=await readBody(req); const msg=redactSensitive(body.message); if(!msg) return json(res,422,{error:'EMPTY_MESSAGE'});
      const mid=id('msg'),t=now(),delivered=(userStreams.get(targetId)?.size||0)>0;
      db.prepare('INSERT INTO chat_messages(id,user_id,sender_type,sender_id,body,status,created_at,delivered_at) VALUES(?,?,?,?,?,?,?,?)')
        .run(mid,targetId,'ADMIN',ctx.admin.id,msg,delivered?'DELIVERED':'SENT',t,delivered?t:null);
      const payload={id:mid,user_id:targetId,sender_type:'ADMIN',sender_name:ctx.admin.full_name,body:msg,status:delivered?'DELIVERED':'SENT',created_at:t};
      broadcastUser(targetId,'chat.message',payload); broadcastAdmins('chat.message',payload);
      return json(res,201,payload);
    }

    const typingMatch=pathname.match(/^\/api\/admin\/users\/([^/]+)\/typing$/);
    if(typingMatch && req.method==='POST') {
      const ctx=enforceAdmin(req,res,'chat'); if(!ctx) return;
      if(!verifyCsrf(req,ctx.session)) return json(res,403,{error:'CSRF'});
      const body=await readBody(req); broadcastUser(decodeURIComponent(typingMatch[1]),'chat.typing',{typing:!!body.typing,admin:ctx.admin.full_name});
      return json(res,200,{ok:true});
    }

    if(pathname==='/api/admin/audit' && req.method==='GET') {
      const ctx=enforceAdmin(req,res,'audit'); if(!ctx) return;
      const rows=db.prepare(`SELECT l.*,a.email admin_email,a.full_name admin_name,u.full_name target_name FROM audit_log l JOIN admins a ON a.id=l.admin_id LEFT JOIN users u ON u.id=l.target_user_id ORDER BY l.created_at DESC LIMIT 500`).all();
      return json(res,200,{audit:rows.map(r=>({...r,previous_state:parseJsonSafe(r.previous_state),new_state:parseJsonSafe(r.new_state),metadata:parseJsonSafe(r.metadata)}))});
    }
    if(pathname==='/api/admin/activity' && req.method==='GET') {
      const ctx=enforceAdmin(req,res,'monitor'); if(!ctx) return;
      const rows=db.prepare(`SELECT l.*,u.full_name FROM activity_log l JOIN users u ON u.id=l.user_id ORDER BY l.created_at DESC LIMIT 500`).all();
      return json(res,200,{activity:rows});
    }
    if(pathname==='/api/admin/admins' && req.method==='GET') {
      const ctx=enforceAdmin(req,res,'manage_admins'); if(!ctx) return;
      const rows=db.prepare('SELECT id,email,full_name,role,created_at,active FROM admins ORDER BY created_at DESC').all();
      return json(res,200,{admins:rows});
    }
    if(pathname==='/api/admin/admins' && req.method==='POST') {
      const ctx=enforceAdmin(req,res,'manage_admins'); if(!ctx) return;
      if(!verifyCsrf(req,ctx.session)) return json(res,403,{error:'CSRF'});
      const body=await readBody(req), email=String(body.email||'').toLowerCase().trim(), fullName=normalizeName(body.full_name), role=String(body.role||'');
      if(!email.includes('@') || fullName.length<3 || !PERMISSIONS[role] || String(body.password||'').length<12) return json(res,422,{error:'INVALID_ADMIN'});
      const aid=id('adm');
      db.prepare('INSERT INTO admins(id,email,full_name,role,password_hash,created_at,active) VALUES(?,?,?,?,?,?,1)').run(aid,email,fullName,role,hashPassword(String(body.password)),now());
      audit(ctx.admin,null,'ADMIN_CREATED',null,{admin_id:aid,email,role},body.reason||'',{});
      return json(res,201,{id:aid,email,full_name:fullName,role});
    }

    if(pathname==='/events/admin' && req.method==='GET') {
      const ctx=enforceAdmin(req,res); if(!ctx) return;
      res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});
      res.write('retry: 2000\n\n'); addStream(adminStreams,ctx.admin.id,res); sseWrite(res,'ready',{admin_id:ctx.admin.id}); return;
    }

    if (pathname==='/api/test/reset' && TEST_MODE && req.method==='POST') {
      db.exec('DELETE FROM navigation_commands; DELETE FROM audit_log; DELETE FROM activity_log; DELETE FROM chat_messages; DELETE FROM user_sessions; DELETE FROM users; DELETE FROM admin_sessions;');
      return json(res,200,{ok:true});
    }

    if (pathname.startsWith('/api/') || pathname.startsWith('/events/')) return json(res,404,{error:'NOT_FOUND'});
    if (serveStatic(req,res,pathname)) return;
    return text(res,404,'Not Found');
  } catch (err) {
    console.error(err);
    if (!res.headersSent) return json(res,500,{error:'SERVER_ERROR'});
    try { res.end(); } catch {}
  }
}

const server=http.createServer(handler);
server.listen(PORT, '127.0.0.1', () => console.log(`KB realtime server: http://127.0.0.1:${PORT}`));

function shutdown(){ try{server.close(()=>{db.close();process.exit(0);});}catch{process.exit(0);} }
process.on('SIGTERM',shutdown); process.on('SIGINT',shutdown);
